import React from 'react'
import InnerBanner from '../helpers/InnerBanner'

const Wishlist = () => {
    return (
        <div>
            <div>
                <InnerBanner innerBannerTile="Contact Us" innerBannerBreadcrumbs="Contact Us" />
            </div>

        </div>
    )
}

export default Wishlist
