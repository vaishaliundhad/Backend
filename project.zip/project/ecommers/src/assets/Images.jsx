import ProductImages1 from "../assets/Product1.jpg";
import ProductImages2 from "../assets/Product2.jpg";
import ProductImages3 from "../assets/Product3.jpg";
import ProductImages4 from "../assets/Product4.jpg";
import ProductImages5 from "../assets/Product5.jpg";
import ProductImages6 from "../assets/Product6.jpg";
import ProductImages7 from "../assets/Product7.jpg";
import ProductImages8 from "../assets/Product8.jpg";
import ProductImages9 from "../assets/Product9.jpg";
import ProductImages10 from "../assets/Product10.jpg";

export const ProductImages = [
  { image: ProductImages1, name: "ProductImages1" },
  { image: ProductImages2, name: "ProductImages2" },
  { image: ProductImages3, name: "ProductImages3" },
  { image: ProductImages4, name: "ProductImages4" },
  { image: ProductImages5, name: "ProductImages5" },
  { image: ProductImages6, name: "ProductImages6" },
  { image: ProductImages7, name: "ProductImages7" },
  { image: ProductImages8, name: "ProductImages8" },
  { image: ProductImages9, name: "ProductImages9" },
  { image: ProductImages10, name: "ProductImages10" },
];