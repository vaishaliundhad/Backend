import './App.css'
import Layout from './pages/Layout'






function App() {
  

  return (
    <>
  <Layout/>
  {/* <Login/> */}
  
    </>
  )
}

export default App
