// import React from 'react'
// import Slider from "react-slick";
// import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";
// import asset1 from '../assets/asset1.jpg'
// import asset2 from '../assets/asset2.jpg'
// import asset3 from '../assets/asset3.jpg'
// import Shopbycategory from '../components/Shopbycategory';
// import { MdKeyboardArrowRight } from "react-icons/md";
// import Scrollsection from '../components/Scrollsection';


// const Home = () => {
//     var settings = {
//         dots: true,
//         infinite: true,
//         speed: 500,
//         autoplay: true,
//         autoplaySpeed: 3000,
//         slidesToShow: 1,
//         slidesToScroll: 1,
//     };

//     return (

//         <>
//         {/* slider */}

//             <div className='overflow-hidden'>
//                 <div className='slider-container '>

//                     <Slider {...settings} className='dots'>

//                         <div className='mainslider1 lg:margin-left:0px p-0 m-0 '>
//                             <img src={asset1} alt="" />
//                             <div className='slide1 '>
//                                 <p className="text-2xl md:text-xl md:ml-2 md:mr-10 max-sm:text-2sm max-sm:hidden ">UP TO 40% OFF CHARGERS AND MORE.</p>
//                                 <h1 className='text-7xl pt-10 md:pt-5 md:w-50 md:text-5xl md:text-md md:mr-9  '>Saving for <br />dads and grads.</h1>
//                                 <button className=' bg-black text-white rounded-full p-3 px-6 text-lg flex mt-10 md:mt-5'>Shop collection <div className='pl-3 pt-2'><MdKeyboardArrowRight /></div></button>
//                             </div>

//                         </div>

//                         <div className='mainslider2' >
//                             <h3><img src={asset2} alt="" /></h3>
//                             <div className='slide2'>
//                                 <p className="text-xl  md:text-xl md:ml-2 md:mr-10 max-sm:text-2sm max-sm:hidden ">UP TO 40% OFF CHARGERS AND MORE.</p>
//                                 <h1 className='text-7xl pt-10 md:pt-5 md:w-50 md:text-5xl md:text-md md:mr-9 '>Modern design</h1>
//                                 <button className='bg-black text-white rounded-full p-3 px-6  text-lg flex mt-10 md:mt-5'>Shop collection <div className='pl-3 pt-2'><MdKeyboardArrowRight /></div></button>
//                             </div>

//                         </div>
//                         <div className='mainslider3'>
//                             <h3><img src={asset3} alt="" /></h3>
//                             <div className='slide3'>
//                                 <p className="text-xl md:text-xl md:ml-2 md:mr-10 max-sm:text-2sm max-sm:hidden">UP TO 40% OFF CHARGERS AND MORE.</p>
//                                 <h1 className='text-7xl pt-10 md:pt-5 md:w-50 md:text-5xl md:text-md md:mr-9'>Fast Charging</h1>
//                                 <button className='bg-black text-white rounded-full p-3 px-6  text-lg flex mt-10 md:mt-5' >Shop collection <div className='pl-3 pt-2'><MdKeyboardArrowRight /></div></button>
//                             </div>

//                         </div>



//                     </Slider>
//                 </div>
             
//             </div>
// <Scrollsection />
// <Shopbycategory />
//         </>
//     );
// }



// export default Home
