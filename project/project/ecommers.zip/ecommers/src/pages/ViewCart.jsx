import React from 'react'
import InnerBanner from '../helpers/InnerBanner'

const ViewCart = () => {
  return (
    <div>
      <div>
        <InnerBanner innerBannerTile="Contact Us" innerBannerBreadcrumbs="Contact Us" />
      </div>
    </div>
  )
}

export default ViewCart
